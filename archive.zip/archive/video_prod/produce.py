from split import * 
from run import *
from join import *

split()
run()
join()